#include <openpose/face/headers.hpp>

namespace op
{
    DEFINE_TEMPLATE_DATUM(WFaceDetector);
    DEFINE_TEMPLATE_DATUM(WFaceExtractorNet);
    DEFINE_TEMPLATE_DATUM(WFaceRenderer);
    DEFINE_TEMPLATE_DATUM(WFaceDetectorOpenCV);
}
