#include <openpose/tracking/headers.hpp>

namespace op
{
    DEFINE_TEMPLATE_DATUM(WPersonIdExtractor);
}
